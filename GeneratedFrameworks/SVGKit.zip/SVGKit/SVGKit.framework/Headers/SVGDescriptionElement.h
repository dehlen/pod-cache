//
//  SVGDescriptionElement.h
//  SVGKit
//
//  Copyright Matt Rajca 2010-2011. All rights reserved.
//

#import "SVGElement.h"

@interface SVGDescriptionElement : SVGElement { }

@end
