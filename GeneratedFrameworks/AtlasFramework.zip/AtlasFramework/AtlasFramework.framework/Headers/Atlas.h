#import <UIKit/UIKit.h>

//! Project version number for Atlas.
FOUNDATION_EXPORT double AtlasVersionNumber;

//! Project version string for Atlas.
FOUNDATION_EXPORT const unsigned char AtlasVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Atlas/PublicHeader.h>


